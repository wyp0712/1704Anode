/**
 * 
 * 箭头函数  
 *  
 * this         定义时
 * 
 * 普通函数this  执行时
 * 
 * 
 * 
 * 
 */


function demo(...val) {

  console.log(val, 'val')
}

demo(1, 2, 3, 4, 5, 6, 6)




