 ### 登录
// some  数组里只要有一个满足条件即为true
// let isExists = arr.some(item => {
//     return item.name == req.body.name && item.upwd == req.body.upwd
// })

// ### 注册
// some 判断有没有此用户
// arr.push()

// ### 搜索
// filter  在数组里筛选出符合条件的项，然后组成一个新数组

// arr.filter(item =>　 {
//     return item.name.indexOf(req.query.val) != -1
// })

// ### tab 级联
// filter

// ### 分页
// slice

// ### 修改和删除
// arr.splice(i, 1, 新的内容)
// app.splice(i, 1)