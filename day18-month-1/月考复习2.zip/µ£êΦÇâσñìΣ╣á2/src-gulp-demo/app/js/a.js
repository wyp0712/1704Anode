const a = () => {
  return 'a'
}

a()