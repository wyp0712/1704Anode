class Base {
  constructor(data, msg) {
    this.data = data;
    this.msg = msg
  }
}

new Base()