const fs = require('fs');;
const path = require('path')
const url = require('url');

function readfileFn(src) {
  return new Promise((resolve, reject) => {
    fs.readFile(src, (err, data) => {
      if (err) {
        reject(err)
        return;
      }
      resolve(data.toString())
    })
  })
}

module.exports = {
  readfileFn
}