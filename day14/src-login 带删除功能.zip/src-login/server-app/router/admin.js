const fs = require('fs');;
const path = require('path')
const url = require('url');
const querystring = require('querystring')
const { SuccessModel, FailModel } = require('../model/resModel')
const { readfileFn } = require('../util/util')

const handleAdminRouter = (req, res) => {

  // 请求方式
  const method = req.method;
  // 请求地址 eg: /movie
  const address = url.parse(req.url).pathname;
  // 通过请求体拿到的post参数
  const postData = req.body;

  // 读取文件数据库路径
  const fileJson = path.join(__dirname, '../', 'Mock', 'user.json')

  if (method === 'GET' && address === '/admin') {
    let { page, size } = req.query;
    return readfileFn(fileJson).then(adminList => {
      let list = JSON.parse(adminList)
      let pageList = list.filter((n, index) => index >= page * 1 * size && index < (page * 1 + 1) * size)
      return new SuccessModel(pageList);
    })
    // return  Promise.resolve(new SuccessModel("注册成功，请登录"))
  }
   
  if (method === 'POST' && address === '/del') {
    let { id } = postData;
    return readfileFn(fileJson).then(delData => {
      let dellist = JSON.parse(delData)
      let data = dellist.filter((n, index) => n.id != id)

     let flag = fs.writeFileSync(fileJson, JSON.stringify(data))
     console.log(flag, 'data')
     if (!flag) {
      return new SuccessModel(data);
     }

    })
  }

}

module.exports = handleAdminRouter
