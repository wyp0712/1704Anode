const ab = require('definemodule');
console.log(ab, 'ab')
